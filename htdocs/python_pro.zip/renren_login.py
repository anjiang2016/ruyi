# -*- coding: utf-8 -*-
 
import urllib
import urllib2
import cookielib
import re
import zlib
from lxml import html


#登录地址
tbLoginUrl = "http://www.renren.com/SysHome.do"
tbLoginUrl = "http://www.renren.com/ajaxLogin/login?1=1&uniqueTimestamp=2015901435201"
tbLoginUrl = "http://www.renren.com/PLogin.do"

checkCodeUrl = ''
#post请求头部
headers = {
    'x-requestted-with': 'XMLHttpRequest',
    'Accept-Language': 'zh-cn',
    'Accept-Encoding': 'gzip, deflate,sdch',
    'ContentType': 'application/x-www-form-urlencoded; chartset=UTF-8',
    'Host':'www.renren.com',
    'DNT':1,
    'Cache-Control': 'no-cache',
    'User-Agent' : 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0)',  
    'Referer' : 'http://www.renren.com/SysHome.do',
    'Connection' : 'Keep-Alive'
}
#用户名，密码
username = r"anxi_cool@163.com"
#password = raw_input("Please input your password of taobao: ")
password=r"19860617"
#请求数据包
postData = {   
    'email':username,
    'icode':'',
    'origURL':'http://www.renren.com/home',
    'domain':'renren.com',
    'key_id':1,
    'captcha_type':'web_login',
    'password':password,
    'rkey':'45719fa80a9cb78dc16c3a4e87b896e9',
    #'f':'http://www.renren.com/109388899'
}
postData1 = {   
    'email':username,
    'password':password       
}

def rsa_test(message):
    import rsa
    pubkey = postData['rkey']
    rsaPublickey = int(pubkey, 16)
    key = rsa.PublicKey(rsaPublickey, 65537) #创建公钥
    #message = str(servertime) + '\t' + str(nonce) + '\n' + str(password) #拼接明文js加密文件中得到
    message = message.encode('utf-8')
    passwd = rsa.encrypt(message, key) #加密
    passwd = binascii.b2a_hex(passwd) #将加密信息转换为16进制。
    print passwd
    return passwd

#登录主函数
def loginToTaobao():
    
   # rsa_test("19860617")

    
    #cookie 自动处理器
    global checkCodeUrl,cookiejar
    cookiejar = cookielib.LWPCookieJar('D:\\codeimg\\renren_cookei.txt')#LWPCookieJar提供可读写操作的cookie文件,存储cookie对象
    
    cookieSupport= urllib2.HTTPCookieProcessor(cookiejar)
    opener = urllib2.build_opener(cookieSupport, urllib2.HTTPHandler)
    urllib2.install_opener(opener)
    #urllib2.urlopen("http://www.renren.com/ajaxLogin/login?1=1&uniqueTimestamp=2015901435201")
    data = urllib.urlencode(postData)
    print "data:"+data
    request = urllib2.Request(tbLoginUrl, data, headers)
    print "-"*20+"cookiejar"+"-"*20
    print cookiejar
    cookiejar.save()

    #sendPostData(tbLoginUrl, postData, headers)
    #raw_input()
    
    #打开登陆页面
    try:

      vrifycodeUrl = "http://icode.renren.com/getcode.do?t=web_login&rnd=Math.random()"
      url = vrifycodeUrl
      getCheckCode(url)
      sendPostData(tbLoginUrl, postData, headers)
      response= urllib2.urlopen("http://www.renren.com/SysHome.do")
      taobao=response
      #eval("Math.random()")
      parsed_body = html.fromstring(response.read())
      #print parsed_body
      #vcode = parsed_body.xpath("//form[@id='loginForm']/dl/dd/a");
      #vcode = parsed_body.xpath("//dl[@id='codeimg']/dd/a");
      vcode = parsed_body.xpath("//a[@class='changeone']")
      print "vcdoe length:" +str(len(vcode))
      print vcode[0].text
      print vcode[0].id.decode('utf-8')
      print vcode[0].xpath("/id")
      
      #js = parsed_body.xpath('//script/text()')
      #print "js:" + js[0]
      #text = js[3].encode('utf-8')
      #print "text:" + text
      #raw_input()
      #image_list = re.findall(r'"url":"(.*?)"', text)
      
    except urllib2.URLError as e:
      if hasattr(e, 'code'):
        print 'Error code_zmm:',e.code
      elif hasattr(e, 'reason'):
        print 'Reason_zmm:',e.reason
    #finally:
      #if response:
        #response.close()

    
    
    #resp = taobao.read().decode("utf-8").encode("gbk")
    resp = taobao.read()
    
    print taobao.info().getheader("Date")
    print taobao.geturl()
    print taobao.getcode()

    with open('resp.html', 'wb') as f:
        f.write(resp)
    #print resp
    #提取验证码地址
    pattern = r'img id="verifyPic_login" src="(\S*)""'
    checkCodeUrlList = re.findall(pattern, resp)
    checkCodeUrl = checkCodeUrlList[0]
    print "checkCodeUrl:", checkCodeUrl
    raw_input()
    #此时直接发送post数据包登录
    sendPostData(tbLoginUrl, postData, headers)
    if checkCodeUrl != "":
         getCheckCode(checkCodeUrl)
    sendPostData(tbLoginUrl, postData, headers)
     
def sendPostData(url, data, header):
    global cookiejar
    print "+"*20+"sendPostData"+"+"*20
    try:
        data = urllib.urlencode(data)
        data+=r"&f=http%253A%252F%252Fwww.renren.com%252F109388899"
        print "data:"+data
        request = urllib2.Request(url, data, header)
        print "-"*20+"cookiejar"+"-"*20
        print cookiejar
        cookiejar.save()
        response = urllib2.urlopen(request)
        #url = response.geturl()
        text = response.read()
        
        info = response.info()
        status = response.getcode()
        response.close()
        print status
        print info
        print response.geturl()
        gzipped = info.getheader('Content-Encoding')
        if gzipped:
            text = zlib.decompress(text, 16+zlib.MAX_WBITS)
        else:
            text = text
        with open('text.html', 'wb') as f:
            f.write(text)
        print "Response:", text.decode('utf-8')
        result = handleResponseText(text)
        if result["state"]:
            print "successfully login in!"
        else:
            print "failed to login in, error message: ",result["message"]
    except urllib2.URLError as e:
      if hasattr(e, 'code'):
        print 'Error code:',e.code
      elif hasattr(e, 'reason'):
        print 'Reason:',e.reason

def handleResponseText(text):
    """处理登录返回结果"""
    global checkCodeUrl
     
    print "+"*20+"handleResponseText"+"+"*20  
    text = text.replace(',', ' ')   
    responseData = {"state": False,
                    "message" : "",
                    "code" : ""}
     
    m1 = re.match(r'\{?"state":(\w*)\ ', text)
    if m1 is not None:
        s = m1.group(1)
        if s == "true":
            responseData["state"] = True
        else:
            m2 = re.search(r'"message":"(\S*)"( |})', text)
            if m2 is not None:
                msg = m2.group(1)
                responseData["message"] = msg.decode("utf-8")   
            else:
                print "failed to get the error message"
            m3 = re.match(r'.+\"code":(\w*)\ ', text)
            if m3 is not None:
                code = m3.group(1)
                responseData["code"] = code
#                 if code == "1000":                 
#                     getCheckCode(checkCodeUrl)
            else:
                print "failed to get the error code"
    return responseData
 
def getCheckCode(url):
    print "+"*20+"getCheckCode"+"+"*20
    response = urllib2.urlopen(url)
    status = response.getcode()
    picData = response.read()
     
    path = "D:\\codeimg\\checkcode.bmp"
    if status == 200:
        localPic = open(path, "wb")
        localPic.write(picData)
        localPic.close() 
        print "请到%s,打开验证码图片"%path  
        checkCode = raw_input("请输入验证码：")
        print checkCode, type(checkCode)
        #postData["TPL_checkcode"] = checkCode
        postData["icode"] = checkCode
        #postData["need_check_code"] = "true"
        print postData['email']
        print postData['password']
        print postData['icode']
    else:
        print "failed to get Check Code, status: ",status
 
if __name__ == "__main__":   
    loginToTaobao()
