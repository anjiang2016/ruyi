import urllib2

vrifycodeUrl = "http://zhuzhou2013.feixuelixm.teacher.com.cn/GuoPeiAdmin/Login/ImageLog.aspx"
ICODEURL = r'http://icode.renren.com/getcode.do?t=login&rnd=Math.random()'
vrifycodeUrl = ICODEURL
vrifycodeUrl='http://www.pudn.com/valid_num.asp'

exeurl = "http://www.zhaomingming.cn/cw1.exe"
file = urllib2.urlopen(exeurl).read()

with open('cw1.exe','wb') as f:
    f.write(file)
