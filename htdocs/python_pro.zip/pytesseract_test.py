#!/usr/bin/env python
# -*- coding: gbk -*-
# -*- coding: utf_8 -*-
# Date: 2014/11/27
# Created by ���Եȴ�
# ���� http://www.waitalone.cn/
#try:
from pytesser import pytesser
#import pytesseract
from PIL import Image
import urllib2
import cStringIO
#except ImportError:
#  print 'ģ�鵼�����,��ʹ��pip��װ,pytesseract�������¿⣺'
#  print 'http://www.lfd.uci.edu/~gohlke/pythonlibs/#pil'
#  print 'http://code.google.com/p/tesseract-ocr/'
#  raise SystemExit


vrifycodeUrl = "http://zhuzhou2013.feixuelixm.teacher.com.cn/GuoPeiAdmin/Login/ImageLog.aspx"
ICODEURL = r'http://icode.renren.com/getcode.do?t=login&rnd=Math.random()'
vrifycodeUrl = ICODEURL
vrifycodeUrl='http://www.pudn.com/valid_num.asp'
file = urllib2.urlopen(vrifycodeUrl).read()

img = cStringIO.StringIO(file) # constructs a StringIO holding the image  AttributeError: addinfourl instance has no attribute 'seek'

im = Image.open(img)
im.show()
im.save('1.bmp')
text = pytesser.image_to_string(im)
print "vrifycode:", text
im = Image.open('1.bmp')
text = pytesser.image_to_string(im)
print "vrifycode:", text
image = Image.open('vcode2.jpg')
vcode = pytesser.image_to_string(image)
print vcode
