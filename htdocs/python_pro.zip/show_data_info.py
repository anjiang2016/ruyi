import MySQLdb
 
try:

    hostname='hdm-122.hichina.com'
    username = 'hdm1220044'
    dbname='hdm1220044_db'
    
    #conn=MySQLdb.connect(host='localhost',user='root',passwd='0304028Ms',port=3306)
    conn=MySQLdb.connect(host=hostname,user=username,passwd='0304028Ms',port=3306)
    
    cur=conn.cursor()
    count=cur.execute('show databases')
    #print 'there has %s rows record' % count
    results=cur.fetchall()
    #for r in results:
    #    print r[0]

    conn.select_db('hdm1220044_db')   

    #count=cur.execute('show tables')
    #print 'there has %s rows record' % count
    #results=cur.fetchall()
    #for r in results:
    #    print r[0]
     
    
 
    count=cur.execute('select * from zmm_renren_datainfo1')
    print 'there has %s rows record' % count

    #results=cur.fetchall()
    results=cur.fetchmany(100)
    #print results
    for r in results:
        print r
    
    #result=cur.fetchone()
    #print result
    #print 'ID: %s , %s, %s, %s, %s, %s' % result
 
    #results=cur.fetchmany(5)
    #for r in results:
    #    print r
 
    print '=='*10
    #cur.scroll(0,mode='absolute')
 
    #results=cur.fetchall()
    #for r in results:
     #   print str(r[0])+","+r[1]+","+ r[2]+","+r[3]+","+r[4]+","+r[5]
     
 
    conn.commit()
    cur.close()
    conn.close()
 
except MySQLdb.Error,e:
     print "Mysql Error %d: %s" % (e.args[0], e.args[1])
