# -*- coding: cp936 -*-
import MySQLdb
 
try:
    hostname='hdm-122.hichina.com'
    username = 'hdm1220044'
    dbname='hdm1220044_db'
    
    #conn=MySQLdb.connect(host='localhost',user='root',passwd='0304028Ms',port=3306)
    conn=MySQLdb.connect(host=hostname,user=username,passwd='0304028Ms',port=3306)
    cur=conn.cursor()
     
    #cur.execute('create database if not exists zmm_renren_datainfo')
    #conn.select_db('zmm_renren_datainfo')
    conn.select_db('hdm1220044_db')   
    #cur.execute('create table zmm_renren_datainfo (id int,configinfo varchar(300),dirnumber int,size varchar(20),filenumber int,percent varchar(20))')
    #cur.execute('create table zmm_renren_datainfo1 (id int,configinfo varchar(300),dirnumber varchar(30),size varchar(20),filenumber varchar(30),percent varchar(20))')
    cur.execute('truncate table zmm_renren_datainfo1')
    cur.execute('drop table zmm_renren_datainfo1')
    cur.execute('create table IF NOT EXISTS zmm_renren_datainfo1 (id int PRIMARY KEY NOT NULL AUTO_INCREMENT,configinfo varchar(300),dirnumber varchar(30),size varchar(20),filenumber varchar(30),percent varchar(20))')
    #NOT NULL AUTO_INCREMENT
     
    value=[1,'configrenren_test',99,'99MB',999,'percent 3']
    #instr = "'%s', '%s', '%d', '%s', '%s', '%s', '%s'" %(softname, procversion, int(percent), exe, description, company, procurl)
    instr= "'%d', '%s', '%d', '%s', '%d', '%s'" %(value[0],value[1],value[2],value[3],value[4],value[5])
    print instr
    #cur.execute('insert into zmm_renren_datainfo values('+instr+')')
    cur.execute('insert into zmm_renren_datainfo1 values(%s,%s,%s,%s,%s,%s)',value)
     
    values=[]
    for i in range(2,53*3):
        values.append((i,'configrenren_test','99+i','99MB','999+10*i','%3%'+str(i)))
    cur.executemany('insert into zmm_renren_datainfo1 values(%s,%s,%s,%s,%s,%s)',values)    
    #cur.executemany("'insert into zmm_renren_datainfo values('%d','%s','%d','%s','%d','%s')"%(value[0],value[1],value[2],value[3],value[4],value[5]))
 
    #cur.execute('update test set info="I am rollen" where id=3') #����

    
    
    conn.commit()
    cur.close()
    conn.close()
 
except MySQLdb.Error,e:
     print "Mysql Error %s: %s" % (e.args[0], e.args[1])
