# -*- coding: gbk -*-
# �����������
import sys
import os
import re
import ConfigParser
import requests
import time
from facedetect import Facedetector
from bs4 import BeautifulSoup
from lxml import html
from multiprocessing.dummy import Pool as ThreadPool
from datetime import datetime
#import wx
from os.path import join, getsize
from email.header import Header
from email.mime.text import MIMEText
# from email.mime.multipart import MIMEMultipart
import smtplib, datetime
# import ctypes

#dll = ctypes.cdll.LoadLibrary("facedetectordll.dll")
# dll = ctypes.cdll.LoadLibrary('C:\\Users\\Administrator\\Desktop\\clawler_all_version\\clawler\\clawler_windows_v2f\\clawlerFiles\\facedetect\\facedetectordll.dll')

session = None
start_dir ='d:\images'
imgpath='';
sign_cha=['��','��','��','��Ҽ��������½��ƾ�ʰ','�٢ڢۢܢݢޢߢ���','�� �� �� �� �� �� �� �� �� ��']
#face_num_txt=['��','Ҽ','��','��','��','��','½','��','��','��','ʰ','��','��','��','��','��','��','��','��','��','��']
face_num_txt=['O','��','��','��','��','��','��','��','��','��','��','11','12','13','14','15','16','17','18','19','20']
def create_session():
    global session
    headers = get_headers(get_config())
    s = requests.session()
    login_data = get_login_data()
    try:
        response = s.post('http://www.renren.com/PLogin.do', data=login_data, headers=headers)

    except Exception, e:
        print "position:"
        print "func:create_session"
        print e
    session = s

# ��ȡ��¼�õ��û���������
def get_login_data():
    config = ConfigParser.RawConfigParser()
    config.read(cur_file_dir() + '/'+'user.ini')
    ld = {'email':config.get('logindata', 'email'),'password':config.get('logindata','password')}
    return ld
# ��ȡ�߳���
def get_number_of_threads_day():
    config = ConfigParser.RawConfigParser()
    config.read(cur_file_dir() + '/'+'user.ini')
    return int(config.get('number_of_threads', 'number_of_threads_day'))
# ��ȡ�߳���
def get_number_of_threads_night():
    config = ConfigParser.RawConfigParser()
    config.read(cur_file_dir() + '/'+'user.ini')
    return int(config.get('number_of_threads', 'number_of_threads_night'))

# ��ȡͼƬ����·��
def get_start_para():
    global start_dir,configpath
    print "��ǰ·��=%s"%cur_file_dir()
    #print "cdf=%s"%GetParentPath(cur_file_dir())

    config = ConfigParser.RawConfigParser()
    config.read(cur_file_dir() +'/'+ 'user.ini')
    start_dir=config.get('dir','start_dir')
    print "����·����[%s]\n"%start_dir

    configpath =config.get('file','configfile')
    print "�����ļ���[%s]\n"%configpath

# ��ȡ����
def get_config():
    global configpath
    config = ConfigParser.RawConfigParser()
    config.read(cur_file_dir() + '/'+configpath)

    return config
#��ȡ�ű��ļ��ĵ�ǰ·��

def cur_file_dir():
     # #��ȡ�ű�·��
     # path = sys.path[0]
     # #�ж�Ϊ�ű��ļ�����py2exe�������ļ�������ǽű��ļ����򷵻ص��ǽű���Ŀ¼�������py2exe�������ļ����򷵻ص��Ǳ������ļ�·��
     # if os.path.isdir(path):
     #     return path
     # elif os.path.isfile(path):
     #     return os.path.dirname(path)
     op=os.popen('cd')


     return GetParentPath(sys.argv[0])
def GetParentPath(strPath):
    if not strPath:
        return None
    lsPath = os.path.split(strPath)
    #print(lsPath)
    #print("lsPath[1] = %s" %lsPath[1])
    if lsPath[1]:
        return lsPath[0]

    lsPath = os.path.split(lsPath[0])
    return lsPath[0]


def get_rid(config):
    global number_id,order_list,rid_list
    person_list = []
    order_list=[]
    rid_list = config.options('person')
    number_id = len(rid_list)
    print "ID�ܸ�����%s\n"%len(rid_list)
    i=0
    for rid in rid_list:
        person_list.append(rid.strip())
        order_list.append(str(i))
        i += 1
    return person_list

def get_rid_id(start_num,end_number):
    global number_id
    order_list=[]
    for i in range(start_num,end_number):
        order_list.append(str(i))
    return order_list


# ��װHTTP����ͷ
def get_headers(config):
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Encoding': 'gzip, deflate, sdch',
        'Accept-Language': 'en-US,en;q=0.8,zh-CN;q=0.6,zh;q=0.4,zh-TW;q=0.2,ru;q=0.2,fr;q=0.2,ja;q=0.2',
        'Cache-Control': 'max-age=0',
        'Connection': 'keep-alive',
        'Host': 'www.renren.com',
        'RA-Sid': 'DAF1BC22-20140915-034057-065a39-2cb2b1',

        'RA-Ver': '2.10.4',
        'Referer': 'http://www.renren.com/SysHome.do',
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.130 Safari/537.36',
    }

    # �������ļ���ȡ���û�cookie
    headers['Cookie'] = config.get('cookie', 'cookie')

    return headers


# �������б�
def get_albums(url):
    global session,num_of_dir
    # if session == None:
    #     create_session()
    s = session
    try:
        parsed_body = html.fromstring(s.get(url, timeout=15).content)
    except Exception, e:
        print "position:"
        print "func:get_albums"
        print e
        return {}
    time.sleep(0.1)
    js = parsed_body.xpath('//script/text()')
    js = map(lambda x: x.encode('utf-8'), js)

    # ���������ڵ�js��
    album_js = js[3]
    try:
        album_raw = re.findall(r"'albumList':\s*(\[.*?\]),", album_js)[0]
    except Exception, e:
        print "position:"
        print "func:get_albums"
        print e
        num_of_dir-=0
        album_raw = '[]'
    #print "behind try"
    album_list = eval(album_raw)

    album_url_dict = {}
    album_url_count=0;
    for album in album_list:
        if album['sourceControl'] == 99:  # ��Ȩ���ʸ���ᣨֻ����ȡ��Ȩ���ʵ���ᣩ
            album_url = 'http://photo.renren.com/photo/'
            album_url = album_url + str(album['ownerId']) + '/'
            album_url = album_url + 'album-' + album['albumId'] + '/v7'

            album_url_dict[album['albumId']] = {}
            album_url_dict[album['albumId']]['album_url'] = album_url
            album_url_count+=1
            album_url_dict[album['albumId']]['photo_count'] = album['photoCount']
            album_url_dict[album['albumId']]['album_name'] = album['albumName']
    if album_url_count==0:
        num_of_dir-=0
    #print "  album_url_count=%d"%(album_url_count)
    return album_url_dict


# ��ȡÿ������е�ͼƬ�б�
def get_imgs(album_url_dict):
    global session,num_of_dir
    # if session == None:
    #     create_session()
    s = session
    img_dict = {}
    img_url_count=0
    for key, val in album_url_dict.iteritems():
        album_url = val['album_url']
        try:
            response = s.get(album_url, timeout=15)
            parsed_body = html.fromstring(response.content)
            js = parsed_body.xpath('//script/text()')
            text = js[3].encode('utf-8')
            image_list = re.findall(r'"url":"(.*?)"', text)
            img_dict[key] = image_list
            img_url_count+=1
        except Exception, e:
            print "position:"
            print "func:get_imgs"
            print e
            num_of_dir-=0
        time.sleep(0.1)
    if img_url_count==0:
        num_of_dir-=0
    #print "    img_url_count=%d"%(img_url_count)

    return img_dict


def download_img(img_dict, start_dir,nd):
    global session,num_of_dir,liveCallflag

    # if session == None:
    #     create_session()
    s = session
    download_img_count=0;
    for album_id, image_list in img_dict.iteritems():

        if not os.path.exists(start_dir):
            os.makedirs(start_dir)

        image_list = map(lambda x: x.replace('\\', ''), image_list)
        number_in_dir=0;
        for url in image_list:
            try:
                #sys.stdout.write('-')
                response = s.get(url, timeout=15)
                url = start_dir + '/' + url.split('/')[-1]
                (filepath,tempfilename) = os.path.split(url)
                (shotname,extension) = os.path.splitext(tempfilename)
                face_num=10
                newurl = filepath+'/'+shotname+face_num_txt[face_num]+'.cigit'
                # with open(start_dir + '/' + url.split('/')[-1], 'wb') as f:
                with open(newurl, 'wb') as f:
                    f.write(response.content)
                    sys.stdout.write('>')
                # ÿ����һ��ͼƬ���������
                # try:
                #     imgpath=start_dir + '/' + url.split('/')[-1]
                #     number_in_dir+=checkface(start_dir + '/' + url.split('/')[-1],nd)
                #     liveCallTimer()
                #
                #
                #
                # except Exception, e:
					# print "face_detect_error: %s,--[%s]"%(e,imgpath)

                download_img_count+=1
            except Exception, e:
                sys.stdout.write(sign_cha[1])
                #print "\nposition:"
                #print "func:download_img"
                #print e

                num_of_dir+=-0
            if download_img_count>2000:
                break
            time.sleep(0.1)
    if download_img_count==0:
        num_of_dir-=0
    sys.stdout.write("\n")

def get_renren_img(rid_list):
    global start_dir,num_of_dir,number_of_threads

    for rid in rid_list:

        name = rid

        url = 'http://photo.renren.com/photo/' + rid + '/albumlist/v7'
        # Ϊÿ���˴���һ���������ļ��д洢���
        dir = os.path.join(start_dir, name)
        if not os.path.exists(dir):
            os.makedirs(dir)
            num_of_dir+=1
            threads_name = num_of_dir
            print "\n ������%s���ļ���[%s]"%(num_of_dir+1,dir)
            #print "%3s,the %3sth dir in dir(renren)\n"%(name,num_of_dir)
            album_url_dict = get_albums(url)
            img_dict = get_imgs(album_url_dict)
            download_img(img_dict, dir,str(threads_name%number_of_threads))
            #checkfaceindir(dir,str(threads_name%number_of_threads))
            # �ļ��в��
            #if not os.listdir(dir):
                 #os.removedirs(dir)
		         #num_of_dir +=-1
                 #print "delete dir:cd %s,the %3sth dir in dir(%s),no file in it"%(dir,num_of_dir,start_dir)


        #else:
		#if not os.listdir(dir):
			#os.removedirs(dir)
			#print "no image in %s,so delete it.\n"%(dir)
			#print "dir is exist:%s"%(dir)
			#num_of_dir+=-1
        # dir is exist,


def get_now_time():
    now = datetime.datetime.now()
    year = now.year
    hour = now.hour
    minute = now.minute
    second = now.second
    return hour
def get_img_parallel(step, begin, end):
    """
    ����ץȡͼƬ
    """
    global rid_list,order_list,number_of_threads
    # get_renren_img(rid_list[2740:])
    hour=get_now_time()
    now=datetime.datetime.now()
    if hour > 20:
        number_of_threads=get_number_of_threads_day()
    elif hour > 22:
        number_of_threads=get_number_of_threads_night()
    elif hour < 9:
        number_of_threads=get_number_of_threads_night()
    else:
        number_of_threads=get_number_of_threads_day()
    pool = ThreadPool(number_of_threads)
    for i in xrange(begin, end, step * number_of_threads):



        print "###################################"
        print "ʱ��:[%d��%d��%d�� %d:%d:%d]"%(now.year,now.month,now.day,now.hour,now.minute,now.second)
        print "�߳���Ŀ=%s,�߳̿�ʼ��ţ�ID)=%s,(rows)=%d"%(number_of_threads,rid_list[i],i+1)

        try:
            if session == None:
                create_session()
            aa=[rid_list[i + j * step: i + (j + 1) * step] for j in xrange(number_of_threads)]

            pool.map(get_renren_img, aa)
        except Exception, e:
            print "position:"
            print "func:get_img_parallel"
            print e
    pool.close()
    pool.join()

#����ļ�����ÿ��ͼƬ������������
def checkfaceindir(dirpath,nd):
    # global session,num_of_dir,liveCallflag
    try:
        source_dir = dirpath

        if not source_dir.endswith('/'):
            source_dir += '/'

        if os.path.isdir(source_dir):
            # copy(source_dir, dest_dir)
            for root, dirs, files in os.walk(source_dir):
                for i in xrange (0, files.__len__()):
                    sf = os.path.join(root, files[i])
                    # print sf
                    checkface(sf,nd)
            print dirpath+'Done!'
        else:
            raise Exception('Wrong path entered!')

    except Exception, e:
        print "face_detect_error: %s,--[%s]"%(e,imgpath)
    liveCallTimer()

# ��� url��ָͼƬ�ں�����������
def checkface(url,nd):
     #time.sleep(0.001)
    #str = "C:/cw/images/323977394/h_large_zeqh_792500014e822f75.jpg";
    # print "url = %s"%url

    # �����������dll
    # sBuf = url
    # fd  = dll.faceDetec
    # fd.argtypes = [ctypes.c_char_p, ctypes.c_int]
    # fd.restypes = ctypes.c_int
    # # nRst = fd(sBuf, len(sBuf))
    # face_num=fd(sBuf, 2)



    #face_num = fd.run(url,nd)
    face_num=10;
    if face_num>0:
        # #print "face_num:%d"%face_num
        # (filepath,tempfilename) = os.path.split(url)
        # (shotname,extension) = os.path.splitext(tempfilename)
        # newurl = filepath+'/'+shotname+face_num_txt[face_num]+'.cigit'
        # # os.renames(urls,url+face_num_txt[face_num]+'.'+url.split('.')[-1])
        # os.renames(url,newurl)

        sys.stdout.write("["+str(nd)+"]"+face_num_txt[face_num])
        return 1
        #sys.stdout.write(face_num_txt[face_num])

    else:
        os.remove(url)
        #print "delete image:no face"
        sys.stdout.write("["+str(nd)+"]"+face_num_txt[face_num])
        return 0

def init_dialog():
    app=wx.App()
    frame=wx.Frame(None)
    frame.SetTitle("��ʼ������")
    frame.SetIcon(wx.Icon('favicon.ico',wx.BITMAP_TYPE_ICO))
    frame.Center()
    #�����˵�
    menubar = wx.MenuBar()
    file=wx.Menu()
    edit = wx.Menu()
    help = wx.Menu()
    #Ȼ��Ϊ�˵����Ӳ˵��������������ַ�ʽ��
    file.Append( 101, '&Open', 'Open a new document' )
    file.Append( 102, '&Save', 'Save the document' )
    #���ǿ���ʹ�ú������ָ��߼�����
    file.AppendSeparator()
    #��������ڲ˵���ʹ�� Icon������Ҫ�ֹ����� MenuItem ����
    #quit=wx.MenuItem(file,105,'&Quit\tCtrl+Q','Quit the Application')
    #quit.SetBitmap(wx.Image('stock_exit-16.png', wx.BITMAP_TYPE_PNG).ConvertToBitmap())
    #file.AppendItem(quit)
    menubar.Append( file, '&File' )
    menubar.Append( edit, '&Edit' )
    menubar.Append( help, '&Help' )
    frame.SetMenuBar(menubar)

    panel = wx.Panel(frame, -1)
    # ����һ�������ľ�̬�ı�
    wx.StaticText(panel, -1, "This is an example of static text",(100, 10))
    frame.Show()

    dlgtext = wx.TextEntryDialog(panel,'What is your favorite programming language?','perl','python')

    dlgtext.SetValue('python is good')

    if dlgtext.ShowModal() == wx.ID_OK:
        # dlgtext.
        dlgmsg = wx.MessageDialog(panel,dlgtext.GetValue(),'A Message Box',wx.OK | wx.ICON_INFORMATION)
        dlgmsg.Center()
        dlgmsg.ShowModal()
        dlgmsg.Destroy()

    dlgtext.Destroy()
    app.MainLoop()

def getdirsize(dir):
   global n_of_file,n_of_dir_nk
   size = 0L
   n_of_file=0
   n_of_dir_nk=0
   for root, dirs, files in os.walk(dir):
       for name in files:
           size+=getsize(join(root,name))
           n_of_file+=1
       for dir in dirs:
           if os.listdir(join(root,dir)):
               #print join(root,dir)
               n_of_dir_nk+=1
       

   return size/1024/1024

def liveCallTimer():
    global liveCallflag
    nowtime=datetime.datetime.now()
    if nowtime.minute>=30 and nowtime.second>=30 and liveCallflag==1:
        liveCallflag=0
        liveCall()
    elif  nowtime.minute<= 30 and nowtime.second<30  and liveCallflag==0:
        liveCallflag=1

def liveCall():
    global n_of_file,configpath,liveCallflag1,n_of_dir_nk,rid_list
    if liveCallflag1==1:
        dir_size = getdirsize(start_dir)
        now = datetime.datetime.now()
        year = now.year
        hour = now.hour
        minute = now.minute
        second = now.second
        timestr = r"ʱ��:[{0:d}��{1:d}��{2:d}�� {3:d}:{4:d}:{5:d}]".format(now.year, now.month, now.day, now.hour, now.minute,now.second)
        timestr1 = r"[{0:d}/{1:d}/{2:d} {3:d}:{4:d}:{5:d}]".format(now.year, now.month, now.day, now.hour, now.minute,now.second)
        
        text  = " "+timestr+" "+start_dir + "["+str(dir_size)+"Mbytes],files number["+str(n_of_file)+"]"
        # msg = MIMEMultipart('adf')
        #msg = MIMEText('���','text','utf-8')

        # att = MIMEText(open('D:\\img3\\318094063\\large_hzqZ_49ed0000aec1118e.jpg', 'rb').read(), 'base64', 'gb2312')
        # att["Content-Type"] = 'application/octet-stream'
        # att["Content-Disposition"] = 'attachment; filename="zhanghongwei.jpg"'
        # msg.attach(att)
        content = "info:"
        ld= get_login_data()
        # for line in ld:
        #     content += " ("+line+","+ ld[line]+") "
        content+=" ("+ld['email']+") "
        content+=" (" +configpath+")"
        print content
        msg = MIMEText(content,_subtype='plain',_charset='gb2312')
        msg['to'] = 'datainfo_cloudwalk@qq.com'
        msg['from'] = '471106585@qq.com'
        msg['subject'] = Header(text+' (' + str(datetime.date.today()) + ')','gb2312')

        # dirn size filen per
        pattern1 = re.compile(r"(\d+)_")
        pattern2 = re.compile(r"_(\d+)")
        
        n1= pattern1.search(configpath)
        #if n1:
        #    print "n1:" + n1.group(1)
        n2 = pattern2.search(configpath)
        #if n2:
        #    print "n2:" + n2.group(1)
            
        updateid = (int(n1.group(1))-1)*3+int(n2.group(1))
        print "updateid:" + str(updateid)
        str(n_of_dir_nk)+'/'+str(len(rid_list))
        per = float(int(float(n_of_dir_nk)/float(len(rid_list))*1000))/10
        perstr = str(n_of_dir_nk)+'/'+str(len(rid_list)) + "->"+str(per)+"%"
        update(updateid,timestr1+" "+configpath+" "+ld['email'],str(n_of_dir_nk),str(dir_size)+"MB",str(n_of_file),perstr)
        #server = smtplib.SMTP('smtp.qq.com')
        #server.login('471106585@qq.com','0304028Pp')
        #error=server.sendmail(msg['from'], msg['to'], msg.as_string())
        #server.close()
        #print(error)

def update(idn,configstr,dirnumberstr,sizestr,filenumberstr,percentstr):
    import MySQLdb
    try:
        hostname='hdm-122.hichina.com'
        username = 'hdm1220044'
        dbname='hdm1220044_db'
        conn=MySQLdb.connect(host=hostname,user=username,passwd='0304028Ms',port=3306)
        cur=conn.cursor()
        conn.select_db('hdm1220044_db')   

        upstr="update zmm_renren_datainfo1 set configinfo='%s',dirnumber='%s',size='%s',filenumber='%s',percent='%s' where id = %d"%(configstr,dirnumberstr,sizestr,filenumberstr,percentstr,idn)
        print upstr
        cur.execute(upstr)
         
        conn.commit()
        cur.close()
        conn.close()
     
    except MySQLdb.Error,e:
         print "Mysql Error %s: %s" % (e.args[0], e.args[1])
def checkDirnofilein():
    global start_dir

    number = 0
    numberall=0
    try:
        print "#####���ļ����б�:"
        for parent,dirnames,filenames in os.walk(start_dir):    #�����������ֱ𷵻�1.��Ŀ¼ 2.�����ļ������֣�����·���� 3.�����ļ�����
            for dirname in  dirnames:                       #����ļ�����Ϣ
                # print "parent is:" + parent
                # print  "dirname is:" + dirname
                numberall+=1

                if not os.listdir(start_dir + "/"+dirname):
                    print "#####  %s"%dirname
                    try:
                        # os.removedirs(start_dir + "/"+dirname)
                        os.removedirs(start_dir + "/"+dirname)
                        number+=1
                    except Exception,e:
                        print "removedirs error:%s"%e
        print "#####���ļ���%d��/���ļ���%d����"%(numberall,number)
    except Exception, e:
        print "error:checkDir(%s)"%e


    #     for filename in filenames:                        #����ļ���Ϣ
    #         print "parent is:"+ parent
    #         print "filename is:" + filename
    # print "the full name of the file is:" + os.path.join(parent,filename) #����ļ�·����Ϣ

    #if not os.listdir(dir):
                 #os.removedirs(dir)
		         #num_of_dir +=-1
                 #print "delete dir:cd %s,the %3sth dir in dir(%s),no file in it"%(dir,num_of_dir,start_dir)

def main():
    global start_dir,num_of_dir,rid_list,liveCallflag,liveCallflag1,n_of_dir_nk,rid_list
    liveCallflag=1
    liveCallflag1=1
    print "version:20151011"
    
    # init_dialog()
    if not os.path.exists(start_dir):
        os.makedirs(start_dir)
    config = get_config()
    rid_list = get_rid(config)
    num_of_dir =-1
    n_of_dir_nk=0
    
    for file in os.listdir(start_dir):
        num_of_dir+=1
    liveCall()
    get_img_parallel(step=2, begin=0 + max(0, 0), end=number_id)
    print "#####�������"
    print "#####"
    checkDirnofilein()
    print "#####�������ļ���С:"
    filesize = getdirsize(start_dir)
    print '#####�������ļ���С:%.3f' %(filesize), 'Mb [%s]' %(start_dir)
    liveCall()

if __name__ == '__main__':

    fd=Facedetector.Facedetector(cur_file_dir())
    #get_login_data()
    print sign_cha[3]
    print sign_cha[4]
    print sign_cha[5]
    get_start_para()

    main()
    #liveCall()
    os.system('pause')
