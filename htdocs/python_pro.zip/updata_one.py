# -*- coding: cp936 -*-
import MySQLdb
#cur.execute('create table zmm_renren_datainfo1 (id int,configinfo varchar(300),dirnumber varchar(30),size varchar(20),filenumber varchar(30),percent varchar(20))')
    
def update(idn,configstr,dirnumberstr,sizestr,filenumberstr,percentstr):
    try:
        hostname='hdm-122.hichina.com'
        username = 'hdm1220044'
        dbname='hdm1220044_db'
        conn=MySQLdb.connect(host=hostname,user=username,passwd='0304028Ms',port=3306)
        cur=conn.cursor()
        conn.select_db('hdm1220044_db')   

        upstr="update zmm_renren_datainfo1 set configinfo='%s',dirnumber='%s',size='%s',filenumber='%s',percent='%s' where id = %d"%(configstr,dirnumberstr,sizestr,filenumberstr,percentstr,idn)
        print upstr
        cur.execute(upstr)
         
        conn.commit()
        cur.close()
        conn.close()
     
    except MySQLdb.Error,e:
         print "Mysql Error %s: %s" % (e.args[0], e.args[1])

         
update(3,'1','2','3','4','5')
