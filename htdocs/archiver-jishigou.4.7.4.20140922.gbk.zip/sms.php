<?php
/**
 *
 * SMS���
 *
 *
 * This is NOT a freeware, use is subject to license terms
 *
 * @copyright Copyright (C) 2005 - 2099 Cenwor Inc.
 * @license http://www.cenwor.com
 * @link http://www.jishigou.net
 * @author ����<foxis@qq.com>
 * @version $Id: sms.php 330 2012-03-14 10:22:00Z wuliyong $
 */

require './include/jishigou.php';
$jishigou = new jishigou();

$jishigou->run('sms');

?>