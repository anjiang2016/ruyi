/**
 * �Ի���ؼ�
 * ʹ�û��߶��ο����뱣��������Ϣ
 *
 * @author     ~ZZ~<505171269@qq.com>
 * @version $Id$
 */
 
__DIALOG_WRAPPER__ = {};
__ScreenLocker_HandleKey__ = null;

/* IE6�и�Bug������������Ի���Ŀ��ȵĻ�����IE6�£��Ի�����100%������ʾ (���ָ���˶Ի���������ݵ�width������������ʾ)*/
DialogManager = {
    'create' : function(id){
        var d = {};
        if (!__DIALOG_WRAPPER__[id]) {
            d = new Dialog(id);
            __DIALOG_WRAPPER__[id] = d;
        } else {
            d = DialogManager.get(id);
        }
        return d;
    },
    'get' : function(id){
        return __DIALOG_WRAPPER__[id];
    },
    'close' : function(id){
		if (__DIALOG_WRAPPER__[id]) {
			if (__DIALOG_WRAPPER__[id].close()) {
				__DIALOG_WRAPPER__[id] = null;
			}
			return true;
		} else {
			return false;
		}
    },
    'onClose' : function (){
        return true;
    },
	
    /* ���ضԻ�����ʽ */
    'loadStyle' : function(){
        var _dialog_js_path = $('#dialog_js').attr('src');
        var _path    = _dialog_js_path.split('/');
        var _dialog_css = _path.slice(0, _path.length - 1).join('/') + '/dialog.css';
        $('#dialog_js').after('<link href="' + _dialog_css + '" rel="stylesheet" type="text/css" />');
    },
	
	'setTitle' : function(id, title) {
		if (__DIALOG_WRAPPER__[id]) {
			__DIALOG_WRAPPER__[id].setTitle(title);
		}
	}
};

//����
ScreenLocker = {
    'style' : {
        'position' : 'absolute',
        'top' : '0px',
        'left' : '0px',
        'backgroundColor' : 'black',
        'opacity' : 0.3,
		'overflow':'hidden',
        'z-index' : 999
    },
    'masker' : null,
    'lock' : function(zIndex){
        if (this.masker !== null) {
            this.masker.width($(document).width()).height($(document).height());
            return true;
        }
        this.masker = $('<div></div>');

        /* IE6 Hack */
        if ($.browser.msie) {
            $('select').css('visibility', 'hidden');
        }
        //var _iframe = $('<iframe></iframe>').css({'opacity':0, 'width':'100%', 'height':'100%'});
        //this.masker.append(_iframe);

        /* ��ʽ */
        this.masker.css(this.style);

        if (zIndex) {
            this.masker.css('zIndex', zIndex);
        }

        /* �����ĵ��Ŀ��� */
        this.masker.width($(document).width()).height($(document).height());

        $(document.body).append(this.masker);
    },
    'unlock' : function(){
        if (this.masker === null) {
            return true;
        }
        this.masker.remove();
        this.masker = null;

        /* IE6 Hack */
        if ($.browser.msie) {
            $('select').css('visibility', 'visible');
        }
    }
};

//�϶�
function draggable(m, c)
{
	var MOUSEDOWN_FLG = false;
	var _x, _y;
	$(c).mousedown(function(event){
		MOUSEDOWN_FLG = true;
		var offset = $(m).offset();
		_x = event.pageX - offset.left;
		_y = event.pageY - offset.top;
		$(m).css({left:event.pageX-_x, top:event.pageY-_y});
	});
	
	$(document).mousemove(function(event){
		if(MOUSEDOWN_FLG){
			$(m).css({left:event.pageX-_x, top:event.pageY-_y});
		}
	}).mouseup(function(event){
		MOUSEDOWN_FLG=false;
	});
}

//�Ի�����
Dialog = function (id){
    /*���ɻ����Ի���*/
    this.id = id;
    this.init();
};
Dialog.prototype = {
    /* Ψһ��ʶ */
    'id' : null,
	/*�Ƿ��б�����*/
	'noTitleBar':false,
    /* �ĵ����� */
    'dom' : null,
    'lastPos' : null,
    'status' : 'complete',
    'onClose' : function (){
		/*��ִ����չ�ú���,���ر�׼�ĶԻ���رպ���*/
        return true;
    },
    'tmp' : {},
    /* ��ʼ�� */
    'init' : function(){
        this.dom = {'wrapper' : null, 'body':null, 'head':null, 'title':null, 'close_button':null, 'content':null};

        /* ����������� */
        this.dom.wrapper = $('<div id="dialog_object_' + this.id + '" class="dialog_wrapper"></div>').get(0);

        /* �����Ի������� */
        this.dom.body = $('<div class="dialog_body"></div>').get(0);
		
		//ʹ���Զ��������
		if (!this.noTitleBar) {
			/* ���������� */
			this.dom.head = $('<div class="dialog_head"></div>').get(0);
	
			/* ���������ı� */
			this.dom.titletxt = $('<span class="dialog_title_icon"></span>').get(0);
			this.dom.title = $('<div class="dialog_title"></div>').append(this.dom.titletxt);
	
			/* �����رհ�ť */
			this.dom.close_button = $('<span class="dialog_close_button">close</span>').get(0);
			
			/* ��� */
			$(this.dom.head).append(this.dom.title).append(this.dom.close_button);
			$(this.dom.body).append(this.dom.head);
		}
		
		/* ������������ */
		this.dom.content = $('<div class="dialog_content"></div>').get(0);
		$(this.dom.body).append(this.dom.content);
        $(this.dom.wrapper).append(this.dom.body).append('<div style="clear:both;display:block;"></div>');

        /* ��ʼ����ʽ */
        $(this.dom.wrapper).css({
            'z-index' : 9999,
            'display' : 'none',
			'position' : 'absolute'
        });
        $(this.dom.body).css({
            'position' : 'relative'
        });
		
		if (!this.noTitleBar) {
			$(this.dom.head).css({
				'cursor' : 'auto'//'move'
			});
			$(this.dom.close_button).css({
				'position' : 'absolute',
				'text-indent' : '-9999px',
				'cursor' : 'pointer',
				'overflow' : 'hidden'
			});
		}
		
        $(this.dom.content).css({
//            'margin' : '0px',
//            'padding' : '0px',
			'overflow' : 'hidden'
        });

        var self = this;

		if (!this.noTitleBar) {
			/* ��ʼ������¼� */
			$(this.dom.close_button).click(function(){
				DialogManager.close(self.id);
			});
	
			/* ���϶� */
			draggable(this.dom.wrapper, this.dom.title);
			/*
			$(this.dom.wrapper).draggable({
				'handle' : this.dom.title
			});*/
		}

        /* �����ĵ��� */
        $(document.body).append(this.dom.wrapper);
    },

    /* ���� */
    'hide' : function(){
        $(this.dom.wrapper).hide();
    },

    /* ��ʾ */
    'show' : function(pos){
        if (pos) {
            this.setPosition(pos);
        }

        /* ������Ļ */
		if (__ScreenLocker_HandleKey__ == null || __ScreenLocker_HandleKey__ == '') {
        	ScreenLocker.lock(999);
			__ScreenLocker_HandleKey__ = this.id;
		}

        /* ��ʾ�Ի��� */
        $(this.dom.wrapper).show();
    },

    /* �ر� */
    'close' : function(){
        if (!this.onClose()) {
            return false;
        }
        /* �رնԻ��� */
        $(this.dom.wrapper).remove();

        /* ������Ļ */
		if (__ScreenLocker_HandleKey__ == this.id) {
        	ScreenLocker.unlock();
			__ScreenLocker_HandleKey__ = null;
		}

        return true;
    },

    /* �Ի������ */
    'setTitle' : function(title){
        $(this.dom.titletxt).html(title);
    },

    /* �ı�Ի������� */
    'setContents' : function(type, options){
        contents = this.createContents(type, options);
        if (typeof(contents) == 'string') {
			contents = evalscript(contents);
            $(this.dom.content).html(contents);
        } else {
            $(this.dom.content).empty();
            $(this.dom.content).append(contents);
        }
    },

    /* ���öԻ�����ʽ */
    'setStyle' : function(style){
        if (typeof(style) == 'object') {
            /* ����ΪCSS */
            $(this.dom.wrapper).css(style);
        } else {
            /* ������ַ���������Ϊ����ʽ�� */
            $(this.dom.wrapper).addClass(style);
        }
    },
    'setWidth' : function(width){
        this.setStyle({'width' : width + 'px'});
    },
    'setHeight' : function(height){
        this.setStyle({'height' : height + 'px'});
    },

    /**
	 * ���ɶԻ�������
	 * options = {
	 * 		'type'				��Ϣ֪ͨ����
	 *		'text'				��Ϣ֪ͨ����
	 *		'button_name'		��ť����
	 *		'yes_button_name'	Yes��ť
	 *		'no_button_name'	No��ť
	 * }
	 */
    'createContents'  : function(type, options){
        var _html = '', self  = this, status= 'complete';
        if (!options) {
            /* ���ֻ��һ������������Ϊ�䴫�ݵ���HTML�ַ��� */
            this.setStatus(status);
            return type;
        }
        switch(type){
            case 'ajax':
                /* ͨ��Ajaxȡ��HTML����ʾ��ҳ����*/
				var _ajax_url = options.url+'&handle_key='+this.id;
				var _ajaxResponse = function(data) {
					//���ڼ���ʱ������������
					if (options.checkerror) {
						if (options.checkerror(data) == false) {
							return false;
						}
					}
                   	self.setContents(data);
                    
					/* ʹ���ϴζ�λ���¶�λ����λ�� */
                    self.setPosition(self.lastPos);
				};
				if (options.post) {
					$.post(_ajax_url, options.post, function(data) {
						_ajaxResponse(data);
					});
				} else {
					$.get(_ajax_url, function(data) {
						_ajaxResponse(data);
					});
				}
                /* ����ʾ���ڼ��� */
                _html = this.createContents('loading', {'text' : 'loading...'});
            break;
            /* ���öԻ���*/
            case 'loading':
				var _css = '';
				if (options.width) {
					_css = "width:"+options.width+"px";
				}
                _html = '<div class="dialog_loading" style="'+_css+'"><div class="dialog_loading_text">' + options.text + '</div></div>';
                status = 'loading';
            break;
            case 'message':
                var type = 'notice';
                if (options.type) {
                    type = options.type;
                }
                _message_body = $('<div class="dialog_message_body"></div>');
                _message_contents = $('<div class="dialog_message_contents dialog_message_' + type + '">' + options.text + '</div>');
                _buttons_bar = $('<div class="dialog_buttons_bar"></div>');
                switch (type){
                    case 'notice':
                    case 'warning':
                        var button_name = "Sure";
                        if (options.button_name) {
                            button_name = options.button_name;
                        }
                        _ok_button = $('<input type="button" class="u-btn" value="' + button_name + '" />');
                        $(_ok_button).click(function(){
							if (options.close_first) {
								DialogManager.close(self.id);
							}
                            if (options.onclick) {
                                if(!options.onclick.call()) {
                                    return;
                                }
                            }
							if (!options.close_first) {
                            	DialogManager.close(self.id);
							}
                        });
                        $(_buttons_bar).append(_ok_button);
                    	break;
                    case 'confirm':
                        var yes_button_name = 'Yes';
                        var no_button_name = 'No';
                        if (options.yes_button_name) {
                            yes_button_name = options.yes_button_name;
                        }
                        if (options.no_button_name) {
                            no_button_name = options.no_button_name;
                        }
                        _yes_button = $('<input type="button" class="u-btn" value="' + yes_button_name + '" />');
                        _no_button = $('<input type="button" class="btnCanl" value="' + no_button_name + '" />');
                        $(_yes_button).click(function(){
							DialogManager.close(self.id);						  
                            if (options.onClickYes) {
                                if (options.onClickYes.call() === false) {
                                    return;
                                }
                            }
                        });
                        $(_no_button).click(function(){
                            DialogManager.close(self.id);
                            if (options.onClickNo) {
                                if (!options.onClickNo.call()) {
                                    return;
                                }
                            }
                        });
                        $(_buttons_bar).append(_yes_button).append(_no_button);
                    break;
                }
                _html = $(_message_body).append(_message_contents).append(_buttons_bar);

            break;
        }
        this.setStatus(status);

        return _html;
    },
    /* ��λ */
    'setPosition'   : function(pos){
        /* �ϴζ�λ */
        this.lastPos = pos;
        if (typeof(pos) == 'string')
        {
            switch(pos){
                case 'center':
                    var left = 0;
                    var top  = 0;
                    var dialog_width    = $(this.dom.wrapper).width();
                    var dialog_height   = $(this.dom.wrapper).height();
					
                    /* left=�������Ŀ���  + (��ǰ�������Ŀ��� - �Ի���Ŀ��� ) / 2 */
                    left = $(window).scrollLeft() + ($(window).width() - dialog_width) / 2;

                    /* top =�������ĸ߶�  + (��ǰ�������ĸ߶� - �Ի���ĸ߶� ) / 2 */
                    top  = $(window).scrollTop()  + ($(window).height() - dialog_height) / 2;
                    $(this.dom.wrapper).css({left:left + 'px', top:top + 'px'});
                break;
            }
        }
        else
        {
            var _pos = {};
            if (typeof(pos.left) != 'undefined') {
                _pos.left = pos.left;
            }
            if (typeof(pos.top)  != 'undefined') {
                _pos.top  = pos.top;
            }
            $(this.dom.wrapper).css(_pos);
        }

    },
    /* ����״̬ */
    'setStatus' : function(code){
        this.status = code;
    },
    /* ��ȡ״̬ */
    'getStatus' : function(){
        return this.status;
    },
    'disableClose' : function(msg){
        this.tmp['oldOnClose'] = this.onClose;
        this.onClose = function(){
            if(msg)alert(msg);
            return false;
        };
    },
    'enableClose'  : function(){
        this.onClose = this.tmp['oldOnClose'];
        this.tmp['oldOnClose'] = null;
    }
};

//DialogManager.loadStyle();
